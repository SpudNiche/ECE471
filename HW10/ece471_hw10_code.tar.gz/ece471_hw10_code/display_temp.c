#include <stdio.h>

int main(int argc, char **argv) {

	printf("You probably want to overwrite this with your own code.\n");

	return 0;
}

