#!/bin/sh

#Print a simple message
echo "Is there an echo in here?"
