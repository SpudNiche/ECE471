#include <stdio.h>

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#include <sys/ioctl.h>
#include <linux/spi/spidev.h>


int main(int argc, char **argv) {

        int spi_fd,i,j;
        double value;
        unsigned char data[3];
        int result;

	/* Open SPI device */

	/* Set SPI Mode_0 */

	/* Set 8 bits per word */

	/* Set 100 kHz max frequency */

	/* Loop forever printing the CH0 and CH1 Voltages 	*/
	/* Once per second.					*/

	return 0;
}
